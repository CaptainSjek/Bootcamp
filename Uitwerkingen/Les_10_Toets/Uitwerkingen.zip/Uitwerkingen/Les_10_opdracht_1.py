# Opdracht 1.
# Maak de expressies af (vul de juiste operator in)
# Let op: soms zijn er meerdere mogelijkheden, 1 antwoord is genoeg.

# print(6 . 3) 	# toont: 18
# print(15 . 13) 	# toont: 2
# print(3 . 3) 	# toont: 1
# print(16 . 3)   # toont: 1
# print(6 . 3) 	# toont: 216

print(6 * 3) 	# toont: 18
print(15 % 13) 	# toont: 2
print(3 / 3) 	# toont: 1
print(16 % 3)   # toont: 1
print(6 ** 3) 	# toont: 216
